/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package joaoatacadao;

import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;
import telas.CadastrarCliente;
import telas.CadastrarFuncionario;
import telas.CadastrarProduto;
import telas.Caixa;
import telas.GerenciaProdutos;
import telas.ListarProdutos;

/**
 *
 * @author lucas
 */
public class JoaoAtacadao {    
    
        
    public static void main(String[] args) {
        //new NewJFrame().setVisible(true);
        //new CadastrarProduto().setVisible(true); 
        //new ListarProdutos().setVisible(true);
        new GerenciaProdutos().setVisible(true);
        //new CadastrarCliente().setVisible(true);
        //new CadastrarFuncionario().setVisible(true);
        //new Caixa().setVisible(true);
        //System.out.println(Arrays.toString(BancoDeDados.leitor("lucas.txt", "aaaaaaaaaaaaaaaaa")) == "null" ? "Não existe" : "Existe" );
        /*try {
            BancoDeDados.remover("eletroeletronicos.txt", "4444");
            } catch (FileNotFoundException ex) {
            Logger.getLogger(JoaoAtacadao.class.getName()).log(Level.SEVERE, null, ex);
        }*/
        //new NewJFrame().setVisible(true);
        //new CadastrarProduto().setVisible(true);
        //new ListarProdutos().setVisible(true);
        //new GerenciaProdutos().setVisible(true);
        //new CadastrarCliente().setVisible(true);
        //new CadastrarFuncionario().setVisible(true);
        //System.out.println(Arrays.toString(BancoDeDados.leitor("lucas.txt", "aaaaaaaaaaaaaaaaa")) == "null" ? "Não existe" : "Existe" );
    }
    
}