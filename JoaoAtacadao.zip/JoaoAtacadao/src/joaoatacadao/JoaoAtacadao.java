package joaoatacadao;

import java.io.IOException;
import java.util.Arrays;
import telas.CadastrarCliente;
import telas.CadastrarFuncionario;
import telas.CadastrarProduto;
import telas.Caixa;
import telas.ListarProdutos;

public class JoaoAtacadao {    
    
    public static void main(String[] args) throws IOException {
        //new ListarProdutos().setVisible(true);
        //new CadastrarFuncionario().setVisible(true);
        new Caixa().setVisible(true);
        //System.out.println(Arrays.toString(BancoDeDados.leitor("lucas.txt", "aaaaaaaaaaaaaaaaa")) == "null" ? "Não existe" : "Existe" );
    }
    
}
